<html>
    <head>
        <title>pemilik</title>
    </head>
    <body>
        <h1>Rahmad Jaka Prasetyo, 28 september 2002</h1>
    </body>    
</html><?php /**PATH C:\xampp\htdocs\jk_project\resources\views/pemilik.blade.php ENDPATH**/ ?>
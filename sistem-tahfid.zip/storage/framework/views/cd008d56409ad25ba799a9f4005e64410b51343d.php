
<?php $__env->startSection('konten'); ?>
<div class="row">
    <div class="col-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <h4 class="card-title">Daftar Hafalan</h4>
                    <a href="<?php echo e(route('tahfid.index')); ?>" class="btn btn-danger">Kembali</a>
                </div>
                <div class="table-responsive pt-3">
                
                    <table class="table table-bordered" id="table-tahfid">
                        <thead>
                            <tr>
                                <th>
                                    NO
                                </th>
                                <th>
                                    Absensi
                                </th>
                                <th>
                                    Kategori
                                </th>
                                <th>
                                    Halaman
                                </th>
                                <th>
                                    Skor
                                </th>
                                <th>
                                    Tanggal
                                </th>
                                <th>
                                    Waktu
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>1</td>
                                <td><?php echo e($item->kehadiran); ?></td>
                                <td><?php echo e($item->kategori); ?></td>
                                <td><?php echo e($item->jml_halaman); ?></td>
                                <td><?php echo e($item->skor_hafalan); ?></td>
                                <td><?php echo e(date('Y-m-d',strtotime($item->tanggal))); ?></td>
                                <td><?php echo e(date('H:i:s',strtotime($item->tanggal))); ?></td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        let documentTitle = $('.card-title').text();
        $('#table-tahfid').dataTable({
            dom: 'Bfrtip',
            buttons: [{
                    extend: 'copyHtml5',
                    title: documentTitle
                },
                {
                    extend: 'excelHtml5',
                    title: documentTitle,
                },
                {
                    extend: 'csvHtml5',
                    title: documentTitle
                },
                {
                    extend: 'pdfHtml5',
                    title: documentTitle,
                    orientation: 'landscape',
                    pageSize: 'LEGAL',

                }
            ]
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ado/projek/sistem-tahfidz/resources/views/tahfid/detail.blade.php ENDPATH**/ ?>

<?php $__env->startSection('konten'); ?>
<div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
            <div id="accordion">
                    <div class="card">
                <div class="d-flex justify-content-between">
                    <h4 class="card-title">Data Absen</h4>
                    <button class="btn btn-primary " data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                        Filter Data
                    </button>
                </div>
                <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                    <div class="card-body">
                        <form action="<?php echo e(url('laporan/absensipengajar')); ?>">
                            <div class="row">
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="form-check-label">Tanggal Mulai</label>
                                        <input type="date" class="form-control" name="tanggal_mulai" id="tanggal_mulai" value="<?php if(isset($_GET['tanggal_mulai'])): ?><?php echo e($_GET['tanggal_mulai']); ?><?php endif; ?>">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="form-check-label">
                                            Tanggal Selesai
                                        </label>
                                        <input type="date" class="form-control" name="tanggal_selesai" id="tanggal_selesai" value="<?php if(isset($_GET['tanggal_selesai'])): ?><?php echo e($_GET['tanggal_selesai']); ?><?php endif; ?>">
                                    </div>
                                </div>
                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <label class="form-check-label">
                                            Kategori
                                        </label>
                                        <select name="status" class="form-control">
                                            <option value="">-Pilih Status-</option>
                                            <option value="Hadir" <?php if(isset($_GET['status']) && $_GET['status']=='Hadir' ): ?> selected <?php endif; ?>>Hadir</option>
                                            <option value="Alpha" <?php if(isset($_GET['status']) && $_GET['status']=='Alpha' ): ?> selected <?php endif; ?>>Alpha</option>
                                            <option value="Izin" <?php if(isset($_GET['status']) && $_GET['status']=='Izin' ): ?> selected <?php endif; ?>>Izin</option>
                                            <option value="Sakit" <?php if(isset($_GET['status']) && $_GET['status']=='Sakit' ): ?> selected <?php endif; ?>>Sakit</option>
                                        </select>
                                    </div>
                                </div>
                                <div>
                                    <button type="submit" class="btn btn-info mt-4">Cari</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                    </div>
                <div class="table-responsive pt-3">
                    <table class="table table-bordered" id="table-presensi">
                        <thead>
                            <tr>
                                <th>
                                    NO
                                </th>
                                <th>
                                    Nama
                                </th>
                                <th>
                                    Status
                                </th>
                                <th>
                                    Tanggal
                                </th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $presensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e(++$key); ?></td>
                                <td><?php echo e($item->nama); ?></td>
                                <td><?php
                                    if($item->kehadiran == 'Alpha'){
                                    echo '<span class="badge badge-danger" style="width:100px">'.$item->kehadiran.'</span>';
                                    }elseif($item->kehadiran == 'Hadir'){
                                    echo '<span class="badge badge-info" style="width:100px">'.$item->kehadiran.'</span>';
                                    }else{
                                    echo '<span class="badge badge-warning" style="width:100px">'.$item->kehadiran.'</span>';
                                    }
                                    ?>
                                </td>
                                <td><?php echo e($item->tanggal); ?></td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        let documentTitle = $('.card-title').text();
        $('#table-presensi').dataTable({
            dom: 'Bfrtip',
            buttons: [{
                    extend: 'copyHtml5',
                    title: documentTitle
                },
                {
                    extend: 'excelHtml5',
                    title: documentTitle,
                },
                {
                    extend: 'csvHtml5',
                    title: documentTitle
                },
                {
                    extend: 'pdfHtml5',
                    title: documentTitle,
                    orientation: 'landscape',
                    pageSize: 'LEGAL',

                }
            ]
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ado/projek/sistem-tahfidz/resources/views/laporan/absensipengajar.blade.php ENDPATH**/ ?>
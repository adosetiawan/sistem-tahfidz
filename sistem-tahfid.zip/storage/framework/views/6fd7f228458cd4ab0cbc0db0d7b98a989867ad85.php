<?php $__env->startSection('konten'); ?>
<form class="row" action="<?php echo e(route('santri.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('POST'); ?>
    <div class="col-md-9">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title"> Tambah Santri</h4>
                <!-- /.box-header -->
                <br>
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home-tab-pane" type="button" role="tab" aria-controls="home-tab-pane" aria-selected="true">Data Santri</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile-tab-pane" type="button" role="tab" aria-controls="profile-tab-pane" aria-selected="false">Data Orang Tua</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact-tab-pane" type="button" role="tab" aria-controls="contact-tab-pane" aria-selected="false">Program</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="disabled-tab" data-bs-toggle="tab" data-bs-target="#login-tab-pane" type="button" role="tab" aria-controls="disabled-tab-pane" aria-selected="false">Akun Login</button>
                    </li>
                </ul>
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="home-tab-pane" role="tabpanel" aria-labelledby="home-tab" tabindex="0">
                        <div class="box-body">
                            <div class="form-group">
                                <label>Nama Lengkap <small data-toggle="tooltip" title="Wajib diisi">*</small></label>
                                <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="alert alert-dabger">
                                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                        <strong>Peringtan</strong> <?php echo e($message); ?>

                                    </div>
                                </small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input name="nama_lengkap" type="text" class="form-control" value="" placeholder="Nama Lengkap">
                            </div>

                            <div class="form-group">
                                <label>Tempat Lahir <small data-toggle="tooltip" title="Wajib diisi">*</small></label>
                                <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="alert alert-dabger">
                                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                        <strong>Peringtan</strong> <?php echo e($message); ?>

                                    </div>
                                </small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input name="tempat_lahir" type="text" class="form-control" placeholder="Masukan Tempat Lahir">
                            </div>

                            <div class="form-group">
                                <label>Tanggal Lahir <small data-toggle="tooltip" title="Wajib diisi">*</small></label>
                                <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="alert alert-dabger">
                                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                        <strong>Peringtan</strong> <?php echo e($message); ?>

                                    </div>
                                </small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input name="tanggal_lahir" type="date" class="form-control" placeholder="Masukan Tanggal lahir">
                            </div>

                            <div class="form-group">
                                <label>Alamat</label>
                                <?php $__errorArgs = ['alamat_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="alert alert-dabger">
                                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                        <strong>Peringtan</strong> <?php echo e($message); ?>

                                    </div>
                                </small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <textarea class="form-control" name="alamat_lengkap" placeholder="Masukan Alamat"></textarea>
                            </div>
                            <div class="form-group">
                                <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Jenis Kelamin</label>
                                    <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="alert alert-dabger">
                                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                            <strong>Peringtan</strong> <?php echo e($message); ?>

                                        </div>
                                    </small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <div class="col-sm-4">
                                        <div class="form-check">
                                            <label class="form-check-label">
                                                <input type="radio" class="form-check-input" name="jenis_kelamin" id="jenis_kelamin1" value="laki-laki" checked>
                                                Laki-Laki
                                            </label>

                                        </div>
                                    </div>
                                    <div class="col-sm-5">
                                        <div class="form-check">
                                            <label class="form-check-label">
                                                <input type="radio" class="form-check-input" name="jenis_kelamin" id="jenis_kelamin2" value="perempuan">
                                                Perempuan
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Unit Sekolah <small data-toggle="tooltip" title="Wajib diisi">*</small></label>
                                <?php $__errorArgs = ['jenjang_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="alert alert-dabger">
                                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                        <strong>Peringtan</strong> <?php echo e($message); ?>

                                    </div>
                                </small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <select name="jenjang_sekolah" class="form-control">
                                    <option value="">-Pilih Unit Sekolah-</option>
                                    <option value="0">Semua Unit Sekolah</option>
                                    <option value="TAHFIZH">TAHFIZH</option>
                                    <option value="MTS">MTS</option>
                                    <option value="MA">MA</option>
                                    <option value="MI">MI</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="profile-tab-pane" role="tabpanel" aria-labelledby="profile-tab" tabindex="0">
                        <div class="form-group">
                            <label>Nama Lengkap Ibu <small data-toggle="tooltip" title="Wajib diisi">*</small></label>
                            <?php $__errorArgs = ['nama_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="alert alert-dabger">
                                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                    <strong>Peringtan</strong> <?php echo e($message); ?>

                                </div>
                            </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input name="nama_ibu" type="text" class="form-control" value="" placeholder="Masukan Nama Ibu">
                        </div>

                        <div class="form-group">
                            <label>Nama Lengkap Ayah <small data-toggle="tooltip" title="Wajib diisi">*</small></label>
                            <?php $__errorArgs = ['nama_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="alert alert-dabger">
                                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                    <strong>Peringtan</strong> <?php echo e($message); ?>

                                </div>
                            </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input name="nama_ayah" type="text" class="form-control" placeholder="Masukan Nama Ayah">
                        </div>
                        <div class="form-group">
                            <label>No Telepon <small data-toggle="tooltip" title="Wajib diisi">*</small></label>
                            <?php $__errorArgs = ['no_telp_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="alert alert-dabger">
                                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                    <strong>Peringtan</strong> <?php echo e($message); ?>

                                </div>
                            </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input name="no_telp_ayah" type="number" class="form-control" placeholder="Masukan No Telepon">
                        </div>
                    </div>

                    <div class="tab-pane fade" id="contact-tab-pane" role="tabpanel" aria-labelledby="contact-tab" tabindex="0">
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Pilihan Kelas</label>

                            <div class="col-sm-9">
                                <?php $__errorArgs = ['kelas_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="alert alert-dabger">
                                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                        <strong>Peringtan</strong> <?php echo e($message); ?>

                                    </div>
                                </small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <select name="kelas_id" class="form-control">
                                    <?php $__empty_1 = true; $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->kelas_nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Pilihan Program</label>

                            <div class="col-sm-9">
                                <?php $__errorArgs = ['program_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="alert alert-dabger">
                                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                        <strong>Peringtan</strong> <?php echo e($message); ?>

                                    </div>
                                </small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <select name="program_id" class="form-control">
                                    <?php $__empty_1 = true; $__currentLoopData = $program; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->program_nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="login-tab-pane" role="tabpanel" aria-labelledby="disabled-tab" tabindex="0">
                        <div class="box-body">
                            <div class="form-group">
                                <label>Email <small data-toggle="tooltip" title="Wajib diisi">*</small></label>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="alert alert-dabger">
                                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                        <strong>Peringtan</strong> <?php echo e($message); ?>

                                    </div>
                                </small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input name="email" type="text" class="form-control" value="" placeholder="Masukan Email">
                            </div>
                            <div class="form-group">
                                <label>Username <small data-toggle="tooltip" title="Wajib diisi">*</small></label>
                                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="alert alert-dabger">
                                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                        <strong>Peringtan</strong> <?php echo e($message); ?>

                                    </div>
                                </small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input name="username" type="text" class="form-control" value="" placeholder="Masukan Username">
                            </div>
                            <div class="form-group">
                                <label>Password <small data-toggle="tooltip" title="Wajib diisi">*</small></label>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="alert alert-dabger">
                                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                        <strong>Peringtan</strong> <?php echo e($message); ?>

                                    </div>
                                </small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input name="password" type="password" class="form-control" value="" placeholder="Masulan Password" autocomplete="off">
                            </div>
                        </div>
                    </div>
                    <p class="text-muted">*) Kolom wajib diisi.</p>
                </div>
                <!-- /.box-body -->
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card">
            <div class="card-body">
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="form-group">
                        <label>Status</label>
                       
                        <div class="form-check">
                            <label class="form-check-label">
                                <input type="radio" class="form-check-input" name="status" id="status1" value="Aktif" checked>
                                Aktif
                            </label>
                        </div>
                        <br>
                        <label>Foto Profil</label>

                        <input type="file" id="student_img" name="student_img">
                        <br><br><br>
                        <button type="submit" class="btn btn-block btn-success">Simpan</button>
                        <a href="" class="btn btn-block btn-info">Batal</a>
                    </div>
                </div>
                <!-- /.box-body -->
            </div>
        </div>
    </div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ado/projek/sistem-tahfidz/resources/views/santri/create.blade.php ENDPATH**/ ?>
<?php $__env->startSection('konten'); ?>
<!-- Small boxes (Stat box) -->
<div class="row">
	<div class="col-md-12">
		<div class="card">
			<form method="post" action="<?php echo e(route('presensi.store')); ?>" enctype="multipart/form-data" accept-charset="utf-8">
			<?php echo method_field('post'); ?>
				<?php echo csrf_field(); ?>
				<div class="card-body">
					<h4 class="card-title">Tambah Presensi</h4>

					<!-- /.box-header -->
					<div class="box-body">

						<div class="form-group">
							<label>Tanggal <small data-toggle="tooltip" title="Wajib diisi">*</small></label>
							<input name="tanggal" type="date" class="form-control date" value="" placeholder="Tanggal">
						</div>
						<div class="form-group">
							<label>Pegawai <small data-toggle="tooltip" title="Wajib diisi">*</small></label>
							<select name="pengajar_id" class="form-control">
							<?php $__empty_1 = true; $__currentLoopData = $pengajar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<?php endif; ?>
							</select>


						</div>
						<div class="form-group">
							<label>Kehadiran<small data-toggle="tooltip" title="Wajib diisi">*</small></label>
							<select name="status" class="form-control">
								<option>---Absensi---</option>
								<option>Hadir</option>
								<option>Alpha</option>
								<option>Izin</option>
								<option>Sakit</option>
							</select>

						</div>
						<div class="form-group">
							<label>Keterangan</label>
							<textarea name="keterangan" class="form-control" placeholder="Keterangan"></textarea>
						</div>
						<div class="form-group">
							<button type="submit" class="btn btn-success">Simpan</button>
							<a class="btn btn-danger">Batal</a>
						</div>
					</div>
					<!-- /.box-body -->
				</div>
			</form>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/sdb/projek/sistem-tahfiz/resources/views/presensi/create.blade.php ENDPATH**/ ?>
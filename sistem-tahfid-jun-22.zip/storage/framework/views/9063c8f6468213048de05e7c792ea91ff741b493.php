
<?php $__env->startSection('konten'); ?>
<div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <h4 class="card-title">Data Tahfidz</h4>
                    <a href="<?php echo e(route('tahfid.create')); ?>" class="btn btn-primary">Tambah Tahfidz</a>
                </div>
                <div class="table-responsive pt-3">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Kehadiran</th>
                                <th>Kategori</th>
                                <th>Total Hafalan</th>
                                <th>Aksi</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>1</td>
                                <td><?php echo e($item->nama_lengkap); ?></td>
                                <td colspan="4">
                                    <form action="<?php echo e(route('tahfid.store')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('POST'); ?>

                                        <div class="row">
                                            <div class="col-md-3">
                                                <input type="hidden" name="santri_id" value="<?php echo e($item->santri_id); ?>">
                                                <select name="kehadiran" class="form-control">
                                                    <option value="">-Pilih Kehadiran-</option>
                                                    <option value="Hadir">Hadir</option>
                                                    <option value="Alpha">Alpha</option>
                                                    <option value="Izin">Izin</option>
                                                    <option value="Sakit">Sakit</option>
                                                </select>
                                            </div>
                                            <div class="col-md-3">
                                                <select name="kategori" class="form-control">
                                                    <option value="">-Pilih Kategori-</option>
                                                    <option value="Setoran">Setoran</option>
                                                    <option value="Mengulang">Mengulang</option>
                                                    <option value="Murojaah">Murojaah</option>
                                                </select>
                                            </div>
                                            <div class="col-md-3">
                                                <input type="text" name="halaman" class="form-control" id="exampleInputName1" placeholder="1 juz, 4 halaman">
                                            </div>
                                            <div class="col-md-3">
                                                <a href="<?php echo e(url('detail?id='.$item->santri_id)); ?>" class="btn btn-primary mr-2">Detail</a>
                                                   
                                                    <button type="submit" class="btn btn-success">Simpan</a>
                                            </div>
                                        </div>
                                    </form>
                                </td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/sdb/projek/sistem-tahfiz/resources/views/tahfid/home.blade.php ENDPATH**/ ?>